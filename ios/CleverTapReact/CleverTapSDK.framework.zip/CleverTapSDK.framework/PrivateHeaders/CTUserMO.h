#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@interface CTUserMO : NSManagedObject

@end

#import "CTUserMO+CoreDataProperties.h"
