
@interface CTBaseHeaderFooterViewController ()

- (instancetype)initWithNibName:(NSString *)nibNameOrNil
                         bundle:(NSBundle *)nibBundleOrNil
                   notification: (CTInAppNotification *)notification;

- (void)layoutNotification;

@end
