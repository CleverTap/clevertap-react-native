#import "CTInAppDisplayViewController.h"

@interface CTHalfInterstitialViewController : CTInAppDisplayViewController

@end
