
#import "CTInboxBaseMessageCell.h"

@class FLAnimatedImageView;

@interface CTInboxSimpleMessageCell : CTInboxBaseMessageCell

@end
