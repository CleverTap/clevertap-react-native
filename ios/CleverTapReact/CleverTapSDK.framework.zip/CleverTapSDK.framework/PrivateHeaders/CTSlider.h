#import <UIKit/UIKit.h>

@interface CTSlider : UISlider

@end
