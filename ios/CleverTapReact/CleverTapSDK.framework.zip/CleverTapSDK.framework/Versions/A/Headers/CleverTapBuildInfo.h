//
//  CleverTapBuildInfo.h
//  CleverTapSDK
//
//  Copyright (c) 2015 WizRocket. All rights reserved.
//

#define WR_SDK_REVISION @"30107"
